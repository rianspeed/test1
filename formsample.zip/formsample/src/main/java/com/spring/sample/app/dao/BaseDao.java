package com.spring.sample.app.dao;

public class BaseDao {

}
